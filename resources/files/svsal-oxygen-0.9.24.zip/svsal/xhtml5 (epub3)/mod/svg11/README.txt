$Id: README.txt 3106 2011-08-24 07:56:19Z eb2mmrt $
$Author: eb2mmrt $

This directory contains a RELAX NG schema, namely svg11-flat.rnc, for
SVG 1.1 (2nd Edition).  It is automatically created by trang from
svg11-flat.dtd, available at
http://www.w3.org/Graphics/SVG/1.1/DTD/svg11-flat.dtd (08-July-2011).

